export const pathTranslations = {
  home: { en: '/', es: '/', fr: '/' },
  'gana-robux': { en: '/official-ways-to-earn-robux-2025', es: '/official-ways-to-earn-robux-2025', fr: '/official-ways-to-earn-robux-2025' },
  trucos: { en: '/roblox-tricks-and-secrets', es: '/trucos', fr: '/astuces' },
  eventos: { en: '/latest-roblox-events-and-rewards', es: '/eventos', fr: '/evenements' },
  novedades: { en: '/roblox-news-and-updates', es: '/novedades', fr: '/nouveautes' },
  codigos: { en: '/active-roblox-promo-codes', es: '/codigos', fr: '/codes' },
  generadores: { en: '/roblox-safety-and-scam-awareness', es: '/generadores', fr: '/generateurs' },
  contacto: { en: '/contact-us', es: '/contacto', fr: '/contact' },
  'mas-articulos': { en: '/all-articles-and-guides', es: '/articulos', fr: '/articles' },
  'robux-gratis-agosto-2025': { en: '/roblox-earn-opportunities-august-2025', es: '/robux-gratis-agosto-2025', fr: '/robux-gratuits-aout-2025' },
  'articulo': { en: '/article/:slug', es: '/articulo/:slug', fr: '/article/:slug' },
  'aviso-legal': { en: '/legal-notice', es: '/aviso-legal', fr: '/avis-legal' },
  'politica-de-privacidad': { en: '/privacy-policy', es: '/politica-de-privacidad', fr: '/politique-de-confidentialite' },
  'terminos-y-condiciones': { en: '/terms-and-conditions', es: '/terminos-y-condiciones', fr: '/termes-et-conditions' }
};

export const getTranslatedPath = (pathKey, lang = 'en', params = {}) => {
  const langPath = pathTranslations[pathKey]?.[lang];
  if (langPath) {
    let finalPath = langPath;
    if (params.slug) {
      finalPath = finalPath.replace(':slug', params.slug);
    }
    return finalPath;
  }
  return '/';
};

export const getPathKey = (pathname, lang = 'en') => {
  const normalizedPath = pathname === '/' ? '/' : pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;

  for (const key in pathTranslations) {
    const templatePath = pathTranslations[key]?.[lang];
    if (templatePath) {
      if (templatePath.includes(':slug')) {
        const baseTemplatePath = templatePath.split('/:')[0];
        if (normalizedPath.startsWith(baseTemplatePath) && baseTemplatePath !== '') {
          return key;
        }
      } else if (templatePath === normalizedPath) {
        return key;
      }
    }
  }

  return null;
};
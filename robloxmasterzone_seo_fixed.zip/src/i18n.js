import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';
import { articles as articles_es } from '@/data/articles_es';
import { articles as articles_en } from '@/data/articles_en';
import { articles as articles_fr } from '@/data/articles_fr';
import esTranslations from '@/locales/es.json';
import enTranslations from '@/locales/en.json';
import frTranslations from '@/locales/fr.json';

const getArticleByLangAndSlug = (lang, slug) => {
  const articles = {
    es: articles_es,
    en: articles_en,
    fr: articles_fr,
  }[lang];
  return articles.find(a => a.slug === slug) || null;
};

i18next
  .use(initReactI18next)
  .init({
    resources: {
      es: { translation: esTranslations },
      en: { translation: enTranslations },
      fr: { translation: frTranslations },
    },
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false,
      format: (value, format, lng) => {
        if (format === 'getArticle') {
          return getArticleByLangAndSlug(lng, value);
        }
        return value;
      }
    }
  });

export default i18next;
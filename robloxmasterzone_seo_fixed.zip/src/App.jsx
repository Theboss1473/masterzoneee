import React, { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import Layout from '@/components/Layout';
import ScrollToTop from '@/components/ScrollToTop';

const Home = lazy(() => import('@/pages/Home'));
const GanaRobux = lazy(() => import('@/pages/GanaRobux'));
const Trucos = lazy(() => import('@/pages/Trucos'));
const Eventos = lazy(() => import('@/pages/Eventos'));
const Novedades = lazy(() => import('@/pages/Novedades'));
const Generadores = lazy(() => import('@/pages/Generadores'));
const Contacto = lazy(() => import('@/pages/Contacto'));
const Articulo = lazy(() => import('@/pages/Articulo'));
const AvisoLegal = lazy(() => import('@/pages/AvisoLegal'));
const PoliticaPrivacidad = lazy(() => import('@/pages/PoliticaPrivacidad'));
const TerminosCondiciones = lazy(() => import('@/pages/TerminosCondiciones'));
const NotFound = lazy(() => import('@/pages/NotFound'));
const Codigos = lazy(() => import('@/pages/Codigos'));
const MasArticulos = lazy(() => import('@/pages/MasArticulos'));
const RobuxGratisAgosto2025 = lazy(() => import('@/pages/RobuxGratisAgosto2025'));

function App() {
  return (
    <>
      <ScrollToTop />
      <Suspense fallback={<div className="dark bg-black text-white flex justify-center items-center h-screen text-2xl font-orbitron">Loading...</div>}>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/official-ways-to-earn-robux-2025" element={<GanaRobux />} />
            <Route path="/roblox-tricks-and-secrets" element={<Trucos />} />
            <Route path="/latest-roblox-events-and-rewards" element={<Eventos />} />
            <Route path="/roblox-news-and-updates" element={<Novedades />} />
            <Route path="/active-roblox-promo-codes" element={<Codigos />} />
            <Route path="/roblox-safety-and-scam-awareness" element={<Generadores />} />
            <Route path="/contact-us" element={<Contacto />} />
            <Route path="/all-articles-and-guides" element={<MasArticulos />} />
} />
            <Route path="/article/:slug" element={<Articulo />} />
            <Route path="/legal-notice" element={<AvisoLegal />} />
            <Route path="/privacy-policy" element={<PoliticaPrivacidad />} />
            <Route path="/terms-and-conditions" element={<TerminosCondiciones />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </Suspense>
    </>
  );
}

export default App;
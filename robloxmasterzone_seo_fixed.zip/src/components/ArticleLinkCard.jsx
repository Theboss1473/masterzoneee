import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

const cardVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: { opacity: 1, x: 0, transition: { duration: 0.4 } }
};

const ArticleLinkCard = ({ article }) => {
  const location = useLocation();
  const { title, slug } = article;

  const articlePath = `/article/${slug}`;
  const articleTitle = title || 'Article';

  return (
    <motion.div variants={cardVariants}>
      <Link 
        to={articlePath} 
        state={{ from: location.pathname }} 
        aria-label={`Read more about ${articleTitle}`}
        className="flex items-center justify-between p-4 rounded-lg bg-gray-900/50 border-2 border-transparent hover:border-purple-500 hover:bg-purple-900/30 transition-all duration-300 group"
      >
        <span className="text-lg text-gray-300 group-hover:text-green-400">{articleTitle}</span>
        <ArrowRight className="h-5 w-5 text-purple-400 group-hover:text-green-400 transition-colors duration-300 transform group-hover:translate-x-1" />
      </Link>
    </motion.div>
  );
};

export default ArticleLinkCard;
import React from 'react';
import { Helmet } from 'react-helmet-async';
import { useLocation, useParams } from 'react-router-dom';
import { pathTranslations } from '@/utils/path-translations';

const HreflangLinks = () => {
    const location = useLocation();
    const params = useParams();

    const getPathKey = (pathname) => {
      const normalizedPath = pathname === '/' ? '/' : pathname.endsWith('/') ? pathname.slice(0, -1) : pathname;

      for (const key in pathTranslations) {
        const templatePath = pathTranslations[key]?.en;
        if(templatePath) {
          if (templatePath.includes(':slug')) {
            const baseTemplatePath = templatePath.split('/:')[0];
            if (normalizedPath.startsWith(baseTemplatePath) && baseTemplatePath !== '') {
              return key;
            }
          } else if (templatePath === normalizedPath) {
            return key;
          }
        }
      }
      return null;
    };

    const pathKey = getPathKey(location.pathname);

    if (!pathKey) {
        return null;
    }
    
    const domain = 'https://robloxmasterzone.com';

    const getHref = (lang) => {
        let pathTemplate = pathTranslations[pathKey]?.[lang] || pathTranslations[pathKey]?.en;
        if (!pathTemplate) return `${domain}/`;
        
        if (params.slug) {
            pathTemplate = pathTemplate.replace(':slug', params.slug);
        }

        if (pathTemplate === '/') return `${domain}/`;

        return `${domain}${pathTemplate}`;
    };

    const enUrl = getHref('en');
    const esUrl = getHref('es');
    const frUrl = getHref('fr');

    return (
        <Helmet>
            <link rel="alternate" hreflang="en" href={enUrl} />
                                    <link rel="alternate" hreflang="x-default" href={enUrl} />
        </Helmet>
    );
};

export default HreflangLinks;
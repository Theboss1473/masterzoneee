import React from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { getTranslatedPath, getPathKey } from '@/utils/path-translations';

const languages = [
  { code: 'en', flag: '🇺🇸' },
];

const LanguageSwitcher = () => {
  const { i18n } = useTranslation();
  const location = useLocation();
  const navigate = useNavigate();
  const params = useParams();
  const { lang: currentLang } = params;

  const changeLanguage = (newLang) => {
    if (currentLang === newLang) return;

    const pathKey = getPathKey(location.pathname, currentLang);
    
    if (pathKey) {
      const newPath = getTranslatedPath(pathKey, newLang, params);
      navigate(newPath);
    } else {
      navigate(`/${newLang}`);
    }
  };

  return (
    <div className="flex items-center gap-1 bg-black/20 p-1 rounded-full border border-purple-800/50">
      {languages.map((lang) => (
        <Button
          key={lang.code}
          onClick={() => changeLanguage(lang.code)}
          variant="ghost"
          size="icon"
          className={`rounded-full transition-all duration-300 ${currentLang === lang.code ? 'bg-purple-600/50 scale-110' : 'opacity-60 hover:opacity-100'}`}
        >
          <span className="text-lg">{lang.flag}</span>
        </Button>
      ))}
    </div>
  );
};

export default LanguageSwitcher;
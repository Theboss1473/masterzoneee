import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const cardVariants = {
  hidden: { opacity: 0, y: 50 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
};

const ArticleCard = ({ article }) => {
  const location = useLocation();
  const { title, description, image, slug, category } = article;

  const articlePath = `/article/${slug}`;
  const articleTitle = title || 'Article';
  const articleDescription = description || `Read more about ${articleTitle}`;
  const altText = image ? `Visual representation for the article: ${title}` : 'Article image';

  return (
    <motion.article
      variants={cardVariants}
      className="bg-gray-900/50 rounded-lg overflow-hidden border-2 border-purple-800/50 flex flex-col group transition-all duration-300 hover:border-purple-500 hover:shadow-2xl hover:shadow-purple-500/30 transform hover:-translate-y-2"
      aria-labelledby={`article-title-${slug}`}
    >
      {image && (
        <div className="relative">
          <img loading="lazy" className="w-full h-48 object-cover" alt={altText} src={image} />
          <div className="absolute top-0 right-0 bg-purple-600 text-white text-xs font-bold px-3 py-1 m-2 rounded-full font-orbitron">{category}</div>
          <div className="absolute bottom-0 left-0 w-full h-16 bg-gradient-to-t from-gray-900 to-transparent"></div>
        </div>
      )}
      <div className="p-6 flex flex-col flex-grow">
        <h3 id={`article-title-${slug}`} className="text-xl font-orbitron font-bold text-white mb-2 group-hover:text-green-400 transition-colors duration-300">{title}</h3>
        {description && <p className="text-gray-400 text-sm mb-4 flex-grow">{description}</p>}
        <div className="mt-auto">
          <Button asChild variant="secondary" className="w-full bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500 text-purple-300 hover:text-white group-hover:bg-green-500 group-hover:text-black group-hover:border-green-500 transition-all duration-300">
            <Link to={articlePath} state={{ from: location.pathname }} aria-label={`Read more about ${articleTitle}`}>
              Read More <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </motion.article>
  );
};

export default ArticleCard;
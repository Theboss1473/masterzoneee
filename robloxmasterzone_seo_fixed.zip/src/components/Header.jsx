import React, { useState } from 'react';
import { NavLink, Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from "@/components/ui/use-toast";

const Header = () => {
  const [isMobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { toast } = useToast();

  const menuItems = [
    { name: 'Home', path: '/' },
    { name: 'Earn Robux (Official)', path: '/official-ways-to-earn-robux-2025' },
    { name: 'Tricks', path: '/roblox-tricks-and-secrets' },
    { name: 'Events', path: '/latest-roblox-events-and-rewards' },
    { name: 'News', path: '/roblox-news-and-updates' },
    { name: 'Codes', path: '/active-roblox-promo-codes' },
    { name: 'Articles', path: '/all-articles-and-guides' },
    { name: 'Safety', path: '/roblox-safety-and-scam-awareness' },
    { name: 'Contact', path: '/contact-us' },
  ];

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleGeneratorsClick = (e, fromMobile) => {
    e.preventDefault();
    toast({
      title: "⚠️ Robux Generators Are A Scam",
      description: "Be careful! Websites offering free Robux are often scams designed to steal your account. Never enter your password on untrusted sites.",
      variant: "destructive",
    });
    if (fromMobile) {
        setMobileMenuOpen(false);
    }
  };

  const renderMenuItem = (item, isMobile = false) => {
    if (item.path === '/roblox-safety-and-scam-awareness') {
      return (
        <a
          key={item.name}
          href={item.path}
          onClick={(e) => handleGeneratorsClick(e, isMobile)}
          className={isMobile ? "font-orbitron text-gray-300 hover:text-white hover:bg-purple-600/20 block px-3 py-2 rounded-md text-base font-medium" : "font-orbitron text-sm font-semibold text-gray-300 hover:text-white transition-colors duration-300 px-3 py-2 rounded-md hover:bg-purple-600/20"}
          role="button"
        >
          {item.name}
        </a>
      );
    }

    const navLinkClass = ({ isActive }) => {
      let classes = isMobile 
        ? `font-orbitron block px-3 py-2 rounded-md text-base font-medium transition-colors duration-300 ${isActive ? 'text-green-400 bg-purple-600/30' : 'text-gray-300 hover:text-white hover:bg-purple-600/20'}`
        : `font-orbitron text-sm font-semibold transition-colors duration-300 px-3 py-2 rounded-md hover:bg-purple-600/20 ${isActive ? 'text-green-400 neon-green-text' : 'text-gray-300 hover:text-white'}`;
      
      if (item.isFeatured && !isMobile) {
        classes += ` ${isActive ? 'bg-green-500/20' : 'text-green-300 hover:text-green-200'}`;
      }
      return classes;
    };

    return (
      <NavLink
        key={item.name}
        to={item.path}
        end={item.path === '/'}
        onClick={() => isMobile && setMobileMenuOpen(false)}
        className={navLinkClass}
        aria-label={`Go to the ${item.name} page`}
      >
        {item.isFeatured && <Star className="inline-block w-4 h-4 mr-1 text-yellow-400" aria-hidden="true" />}
        {item.name}
      </NavLink>
    );
  };

  return (
    <header className="bg-black/50 backdrop-blur-lg sticky top-0 z-50 border-b border-purple-800/50 shadow-lg shadow-purple-500/10">
      <nav className="container mx-auto px-4 sm:px-6 lg:px-8" role="navigation" aria-label="Main Menu">
        <div className="flex items-center justify-between h-20">
          <div className="flex-shrink-1 min-w-0">
            <Link to="/" className="text-lg sm:text-xl md:text-2xl font-orbitron font-bold text-white neon-text block" aria-label="Go to RobloxMasterZone homepage">
              ROBLOX<span className="text-green-400">MASTER</span><wbr />ZONE
            </Link>
          </div>

          <div className="flex items-center flex-shrink-0">
            <div className="hidden md:flex items-center space-x-1 lg:space-x-2">
                {menuItems.map((item) => renderMenuItem(item, false))}
            </div>

            <div className="md:hidden flex items-center ml-2">
              <Button
                onClick={toggleMobileMenu}
                variant="ghost"
                size="icon"
                className="text-gray-300 hover:text-white ml-2"
                aria-label={isMobileMenuOpen ? "Close mobile menu" : "Open mobile menu"}
                aria-expanded={isMobileMenuOpen}
              >
                {isMobileMenuOpen ? <X size={24} aria-hidden="true" /> : <Menu size={24} aria-hidden="true" />}
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="md:hidden bg-black/80 backdrop-blur-sm"
            id="mobile-menu"
          >
            <nav className="px-2 pt-2 pb-3 space-y-1 sm:px-3" role="navigation" aria-label="Mobile Menu">
              {menuItems.map((item) => renderMenuItem(item, true))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
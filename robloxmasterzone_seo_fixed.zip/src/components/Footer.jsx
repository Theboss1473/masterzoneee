import React from 'react';
import { Link } from 'react-router-dom';
import { Twitter, Youtube } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900/50 border-t-2 border-purple-800/50 mt-16">
      <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left">
          <section>
            <span className="text-xl font-orbitron font-bold text-white neon-text">ROBLOX<span className="text-green-400">MASTER</span>ZONE</span>
            <p className="mt-4 text-gray-400 text-sm">
              Your ultimate hub for Roblox guides, news, and tricks. We are an independent fan site dedicated to the Roblox community.
            </p>
            <div className="mt-6 flex justify-center md:justify-start space-x-4">
              <a href="https://x.com/robloxmasterzon" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-purple-400 transition-colors duration-300" aria-label="Visit our Twitter profile"><span className="sr-only">Twitter</span><Twitter /></a>
              <a href="https://youtube.com/@robloxmasterzone" target="_blank" rel="noopener noreferrer" className="text-gray-400 hover:text-purple-400 transition-colors duration-300" aria-label="Visit our YouTube channel"><span className="sr-only">YouTube</span><Youtube /></a>
            </div>
          </section>
          
          <section>
            <p className="font-orbitron font-bold text-white uppercase tracking-wider">Navigation</p>
            <nav className="mt-4 space-y-2" role="navigation" aria-label="Footer Navigation">
              <Link to="/official-ways-to-earn-robux-2025" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">Earn Robux</Link>
              <Link to="/roblox-tricks-and-secrets" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">Tricks</Link>
              <Link to="/latest-roblox-events-and-rewards" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">Events</Link>
               <Link to="/roblox-news-and-updates" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">News</Link>
            </nav>
          </section>

          <section>
            <p className="font-orbitron font-bold text-white uppercase tracking-wider">Legal</p>
            <nav className="mt-4 space-y-2" role="navigation" aria-label="Legal Navigation">
              <Link to="/legal-notice" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">Legal Notice</Link>
              <Link to="/privacy-policy" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">Privacy Policy</Link>
              <Link to="/terms-and-conditions" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">Terms & Conditions</Link>
              <Link to="/contact-us" className="block text-sm text-gray-400 hover:text-purple-400 transition-colors duration-300">Contact</Link>
            </nav>
          </section>
        </div>

        <div className="mt-8 border-t border-purple-800/30 pt-8 text-center text-sm text-gray-500">
          <p>&copy; {new Date().getFullYear()} RobloxMasterZone. All rights reserved.</p>
          <p className="mt-2">RobloxMasterZone is a fan site and is not affiliated with Roblox Corporation. All trademarks are the property of their respective owners.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
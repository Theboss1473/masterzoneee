import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import ArticleLinkCard from '@/components/ArticleLinkCard';
import { articles as guidesArticles } from '@/data/guides_articles';
import { articles as robuxGratisAgosto2025 } from '@/data/robux_gratis_agosto_2025';
import JsonLd from '@/components/JsonLd';
import { Gift, Gamepad2, Brush } from 'lucide-react';

const MasArticulos = () => {
  const canonicalUrl = `https://robloxmasterzone.com/all-articles-and-guides`;
  const pageTitle = "Full Archive of Roblox Guides & Articles (2025)";
  const pageDescription = "Browse the complete archive of Roblox guides, news, and articles from RobloxMasterZone. Find every tip and trick for 2025 in one place.";

  const allGuideArticles = [...guidesArticles, ...robuxGratisAgosto2025];

  const categories = {
    robux_codes: {
      title: 'Robux & Codes',
      icon: Gift,
      articles: allGuideArticles.filter(a => a.thematic === 'robux_codes')
    },
    gaming_tips: {
      title: 'Roblox Games & Playing Tips',
      icon: Gamepad2,
      articles: allGuideArticles.filter(a => a.thematic === 'gaming_tips')
    },
    creation_avatars: {
      title: 'Creation & Avatars',
      icon: Brush,
      articles: allGuideArticles.filter(a => a.thematic === 'creation_avatars')
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const sectionVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": pageTitle,
    "description": pageDescription,
    "url": canonicalUrl,
    "publisher": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    }
  };

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:image" content="https://robloxmasterzone.com/og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content="https://robloxmasterzone.com/og-image.jpg" />
      </Helmet>
      <JsonLd data={pageSchema} />
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-5xl font-orbitron font-extrabold text-center text-white mb-4 neon-text">
            Complete Guides & Articles Archive
          </h1>
          <p className="text-lg text-gray-400 text-center max-w-3xl mx-auto mb-12">
            Explore our library of guides, organized by topic to help you find exactly what you need.
          </p>
        </motion.div>
        
        <motion.div 
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-16"
        >
          {Object.values(categories).map((category, index) => (
            <motion.section key={index} variants={sectionVariants} aria-labelledby={`category-title-${index}`}>
              <div className="flex items-center mb-6">
                <category.icon className="w-8 h-8 text-purple-400 mr-4" aria-hidden="true" />
                <h2 id={`category-title-${index}`} className="text-3xl font-orbitron text-white">{category.title}</h2>
              </div>
              <div className="space-y-4">
                {category.articles.map((article, articleIndex) => (
                  <ArticleLinkCard key={articleIndex} article={article} />
                ))}
              </div>
            </motion.section>
          ))}
        </motion.div>

        <div className="text-center mt-16">
          <p className="text-gray-400">Want to go back? <Link to="/" className="text-purple-400 hover:underline">Return to Home</Link>.</p>
        </div>
      </section>
    </main>
  );
};

export default MasArticulos;
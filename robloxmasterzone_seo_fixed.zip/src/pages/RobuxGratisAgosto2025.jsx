import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { articles } from '@/data/robux_gratis_agosto_2025';
import ArticleCard from '@/components/ArticleCard';
import JsonLd from '@/components/JsonLd';
import { Link } from 'react-router-dom';

const RobuxGratisAgosto2025 = () => {
  const canonicalUrl = `https://robloxmasterzone.com/roblox-earn-opportunities-august-2025`;
  const pageTitle = "Roblox Earning Opportunities & Promo Codes — Aug 2025";
  const pageDescription = "Find official opportunities, promo codes and safe strategies that work in August 2025. This is NOT a generator. We list real promo codes and safe strategies to earn rewards in Roblox.";

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": pageTitle,
    "description": pageDescription,
    "url": canonicalUrl,
    "publisher": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    }
  };

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:image" content="https://robloxmasterzone.com/og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content="https://robloxmasterzone.com/og-image.jpg" />
      </Helmet>
      <JsonLd data={pageSchema} />
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <h1 className="text-4xl md:text-5xl font-orbitron font-extrabold text-center text-green-400 neon-text-green mb-4">
            Ultimate Free Robux Guide (August 2025)
          </h1>
          <p className="text-lg text-gray-300 text-center max-w-3xl mx-auto mb-12">
            Your complete guide to all the promo codes and methods for getting free items in Roblox this month. We only list safe and working methods.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {articles.length > 0 ? (
            articles.map((article, index) => (
              <ArticleCard key={index} article={article} />
            ))
          ) : (
            <p className="text-center text-gray-400 col-span-full">No articles found in this category.</p>
          )}
        </motion.div>
        <div className="text-center mt-12">
          <p className="text-gray-400">Also check our general <Link to="/active-roblox-promo-codes" className="text-purple-400 hover:underline">promo codes list</Link>.</p>
        </div>
      </section>
    </main>
  );
};

export default RobuxGratisAgosto2025;
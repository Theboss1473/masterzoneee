import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import ArticleCard from '@/components/ArticleCard';
import { Gamepad2, Gift, Code, ArrowRight, Star } from 'lucide-react';
import { articles as newsArticlesData } from '@/data/news_articles';
import { articles as guidesArticlesData } from '@/data/guides_articles';
import JsonLd from '@/components/JsonLd';

const Home = () => {
    const canonicalUrl = `https://robloxmasterzone.com/`;
    const pageTitle = "Roblox Guides, Promo Codes & Safety (2025)";
    const pageDescription = "Your #1 source for Roblox guides, promo codes, and legitimate free Robux methods. Stay updated with the latest news and events to master the metaverse in 2025.";
    
    const latestNews = newsArticlesData.slice(0, 3);
    const featuredGuides = guidesArticlesData.slice(0, 6);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
            },
        },
    };

    const homePageSchema = {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "url": "https://robloxmasterzone.com/",
      "name": "RobloxMasterZone",
      "description": pageDescription,
      "publisher": {
        "@type": "Organization",
        "name": "RobloxMasterZone",
        "logo": {
          "@type": "ImageObject",
          "url": "https://robloxmasterzone.com/favicon.svg"
        }
      },
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://robloxmasterzone.com/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    };

    return (
        <main className="dark">
            <Helmet>
                <title>{pageTitle}</title>
                <meta name="description" content={pageDescription} />
                <meta name="robots" content="index, follow" />
                <link rel="canonical" href={canonicalUrl} />
                <meta property="og:title" content={pageTitle} />
                <meta property="og:description" content={pageDescription} />
                <meta property="og:type" content="website" />
                <meta property="og:url" content={canonicalUrl} />
                <meta property="og:image" content="https://robloxmasterzone.com/og-image.jpg" />
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:title" content={pageTitle} />
                <meta name="twitter:description" content={pageDescription} />
                <meta name="twitter:image" content="https://robloxmasterzone.com/og-image.jpg" />
            </Helmet>
            <JsonLd data={homePageSchema} />

            <section
                className="py-20 md:py-32 text-center bg-grid-purple-500/[0.2] relative"
                aria-labelledby="main-heading"
            >
                <div className="absolute pointer-events-none inset-0 flex items-center justify-center dark:bg-black bg-white [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black)]"></div>
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
                    <h1
                        id="main-heading"
                        className="text-5xl md:text-7xl font-orbitron font-extrabold text-white uppercase neon-text tracking-wider"
                    >
                        Master The <span className="text-green-400">Roblox</span> Universe
                    </h1>
                    <p
                        className="mt-6 max-w-3xl mx-auto text-lg md:text-xl text-gray-300"
                    >
                        The best guides, tricks, and updated news to master the world of Roblox in 2025.
                    </p>
                </div>
            </section>
            
            <section className="py-16" aria-labelledby="call-to-action-heading">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                     <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true, amount: 0.2 }}
                        transition={{ duration: 0.5, delay: 0.2 }}
                        className="mb-16 bg-gradient-to-br from-green-500/10 via-black to-black border-2 border-green-400/50 rounded-xl p-8 shadow-2xl shadow-green-500/20 max-w-4xl mx-auto"
                        aria-labelledby="featured-robux-heading"
                    >
                        <div className="flex items-center justify-center mb-4">
                            <Star className="w-8 h-8 text-yellow-400 mr-3" aria-hidden="true" />
                            <h2 id="featured-robux-heading" className="text-3xl font-orbitron font-bold text-center text-green-300">
                                Official Ways to Earn Robux — August 2025
                            </h2>
                        </div>
                        <p className="text-center text-gray-300 max-w-2xl mx-auto mb-6">
                            Check out our complete guide with all the working codes and methods to get free items and accessories this month.
                        </p>
                        <div className="flex justify-center">
                            <Button asChild size="lg" variant="neonGreen">
                                <Link to="/official-ways-to-earn-robux-2025">
                                    View The Guide
                                    <ArrowRight className="ml-2 h-5 w-5" aria-hidden="true" />
                                </Link>
                            </Button>
                        </div>
                    </motion.div>
                </div>
            </section>

            <section aria-labelledby="latest-news-heading" className="py-16 bg-gray-900/30">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 id="latest-news-heading" className="text-4xl font-orbitron font-bold text-center text-white mb-10">Latest News</h2>
                    <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, amount: 0.1 }}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                    >
                        {latestNews.map((article, index) => (
                            <ArticleCard key={index} article={article} />
                        ))}
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, amount: 0.5 }}
                      transition={{ duration: 0.5 }}
                      className="text-center mt-12"
                    >
                      <Button asChild size="lg" variant="neon" className="px-12 py-6 text-lg">
                        <Link to="/roblox-news-and-updates">
                          View All News
                          <ArrowRight className="ml-2 h-5 w-5" />
                        </Link>
                      </Button>
                    </motion.div>
                </div>
            </section>
            
            <section aria-labelledby="featured-guides-heading" className="py-16">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 id="featured-guides-heading" className="text-4xl font-orbitron font-bold text-center text-white mb-10">Featured Guides & Articles</h2>
                     <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, amount: 0.1 }}
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
                    >
                        {featuredGuides.map((article, index) => (
                            <ArticleCard key={index} article={article} />
                        ))}
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true, amount: 0.5 }}
                      transition={{ duration: 0.5 }}
                      className="text-center mt-12"
                    >
                      <Button asChild size="lg" variant="neon" className="px-12 py-6 text-lg">
                        <Link to="/all-articles-and-guides">
                          View All Guides
                          <ArrowRight className="ml-2 h-5 w-5" />
                        </Link>
                      </Button>
                    </motion.div>
                </div>
            </section>

        </main>
    );
};

export default Home;
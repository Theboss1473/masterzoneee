import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import JsonLd from '@/components/JsonLd';

const AvisoLegal = () => {
  const canonicalUrl = `https://robloxmasterzone.com/legal-notice`;
  const pageTitle = "Legal Notice for RobloxMasterZone Website Users";
  const pageDescription = "Review the official legal notice for RobloxMasterZone. This page details website ownership, intellectual property rights, and terms of use for our informational content.";

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Legal Notice for RobloxMasterZone",
    "description": "Official legal notice covering website ownership, intellectual property, and liability limitations for RobloxMasterZone.",
    "author": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    },
    "datePublished": "2025-08-06",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": canonicalUrl
    }
  };


  return <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={canonicalUrl} />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
      </Helmet>
      <JsonLd data={pageSchema} />
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div initial={{
        opacity: 0,
        y: -30
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.7
      }} className="max-w-4xl mx-auto bg-gray-900/50 p-8 rounded-lg border-2 border-purple-800/50">
          <h1 className="text-3xl md:text-4xl font-orbitron font-extrabold text-center text-white neon-text mb-8">
            Official Website Legal Notice
          </h1>

          <article className="prose prose-invert prose-lg max-w-none text-gray-300">
            <p><strong>Last Updated: August 06, 2025</strong></p>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">1. Website Owner Information</h2>
              <p>This website, RobloxMasterZone, is an independent entity and is not affiliated with, endorsed by, or sponsored by Roblox Corporation.</p>
              <ul>
                  <li><strong>Website Name:</strong> RobloxMasterZone</li>
                  <li><strong>Contact:</strong> Via the <Link to="/contact-us" className="text-green-400 hover:underline">contact form</Link> on this site.</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">2. Purpose of the Website</h2>
              <p>The purpose of RobloxMasterZone is to provide information, guides, news, and resources related to the Roblox platform. All content is for informational and entertainment purposes only.</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">3. Intellectual Property</h2>
              <p>All original content on this website, including text, images, and design, is the property of RobloxMasterZone unless otherwise stated. Roblox, its logos, and character names are trademarks of Roblox Corporation. This site is for fan and informational use and does not claim ownership of Roblox's trademarks.</p>
            </section>
            
            <section>
              <h2 className="text-2xl font-bold text-purple-400">4. Limitation of Liability</h2>
              <p>The information provided on this website is for general informational purposes only. While we strive to keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, about the completeness, accuracy, reliability, suitability, or availability with respect to the website or the information, products, services, or related graphics contained on the website for any purpose. Any reliance you place on such information is therefore strictly at your own risk.</p>
              <p>We are not responsible for any actions taken by users on the Roblox platform or for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website.</p>
            </section>
            
            <section>
              <h2 className="text-2xl font-bold text-purple-400">5. Governing Law</h2>
              <p>This legal notice shall be governed by and construed in accordance with the laws of the website owner's jurisdiction, without regard to its conflict of law provisions.</p>
            </section>
          </article>
        </motion.div>
      </div>
    </main>;
};
export default AvisoLegal;
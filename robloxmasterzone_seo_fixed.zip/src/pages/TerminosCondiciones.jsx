import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import JsonLd from '@/components/JsonLd';

const TerminosCondiciones = () => {
  const canonicalUrl = `https://robloxmasterzone.com/terms-and-conditions`;
  const pageTitle = "Terms and Conditions for RobloxMasterZone Usage";
  const pageDescription = "Read the full Terms and Conditions for using RobloxMasterZone. This document outlines your rights and responsibilities when accessing our Roblox guides and content.";

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Terms and Conditions of Use",
    "description": "The official terms and conditions governing the use of the RobloxMasterZone website, its content, and services.",
    "author": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    },
    "datePublished": "2025-08-06",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": canonicalUrl
    }
  };

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={canonicalUrl} />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
      </Helmet>
      <JsonLd data={pageSchema} />
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto bg-gray-900/50 p-8 rounded-lg border-2 border-purple-800/50"
        >
          <h1 className="text-3xl md:text-4xl font-orbitron font-extrabold text-center text-white neon-text mb-8">
            Website Terms and Conditions
          </h1>
          
          <article className="prose prose-invert prose-lg max-w-none text-gray-300">
            <p><strong>Last Updated: August 06, 2025</strong></p>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">1. Agreement to Terms</h2>
              <p>By accessing this website, you are agreeing to be bound by these terms of service, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this site.</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">2. Use License</h2>
              <p>Permission is granted to temporarily download one copy of the materials (information or software) on RobloxMasterZone's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:</p>
              <ul>
                  <li>modify or copy the materials;</li>
                  <li>use the materials for any commercial purpose, or for any public display (commercial or non-commercial);</li>
                  <li>attempt to decompile or reverse engineer any software contained on RobloxMasterZone's website;</li>
                  <li>remove any copyright or other proprietary notations from the materials; or</li>
                  <li>transfer the materials to another person or "mirror" the materials on any other server.</li>
              </ul>
              <p>This license shall automatically terminate if you violate any of these restrictions and may be terminated by RobloxMasterZone at any time.</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">3. Disclaimer</h2>
              <p>The materials on RobloxMasterZone's website are provided on an 'as is' basis. RobloxMasterZone makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">4. Limitations</h2>
              <p>In no event shall RobloxMasterZone or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on RobloxMasterZone's website, even if RobloxMasterZone or a RobloxMasterZone authorized representative has been notified orally or in writing of the possibility of such damage.</p>
            </section>

            <section>
              <h2 className="text-2xl font-bold text-purple-400">5. Modifications</h2>
              <p>By using this website you are agreeing to be bound by the then current version of these terms of service. For more information, please review our <Link to="/privacy-policy" className="text-purple-400 hover:underline">Privacy Policy</Link>.</p>
            </section>
          </article>
        </motion.div>
      </section>
    </main>
  );
};

export default TerminosCondiciones;
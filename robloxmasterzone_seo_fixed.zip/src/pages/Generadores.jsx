import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { allArticles } from '@/data/articles';
import ArticleCard from '@/components/ArticleCard';
import JsonLd from '@/components/JsonLd';
import { Link } from 'react-router-dom';

const Generadores = () => {
  const canonicalUrl = `https://robloxmasterzone.com/roblox-safety-and-scam-awareness`;
  const pageTitle = "Why Free Robux Generators Are Always a Scam (2025)";
  const pageDescription = "Learn the dangers of using so-called 'free Robux generators'. Our guide explains why they are scams and how to protect your Roblox account from being stolen in 2025.";

  const generadoresArticles = allArticles.filter(a => a.categoryKey === 'Generators');

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": pageTitle,
    "description": pageDescription,
    "url": canonicalUrl,
    "publisher": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    }
  };

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:image" content="https://robloxmasterzone.com/og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content="https://robloxmasterzone.com/og-image.jpg" />
      </Helmet>
      <JsonLd data={pageSchema} />
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <h1 className="text-4xl md:text-5xl font-orbitron font-extrabold text-center text-red-500 neon-text mb-4">
            Why Robux Generators Are a Dangerous Scam
          </h1>
          <p className="text-lg text-gray-300 text-center max-w-3xl mx-auto mb-12">
            This section explains why you should NEVER trust a Robux generator. Learn to identify scams and protect your account in 2025.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {generadoresArticles.length > 0 ? (
            generadoresArticles.map((article, index) => (
              <ArticleCard key={index} article={article} />
            ))
          ) : (
             <p className="text-center text-gray-400 col-span-full">No articles found in this category.</p>
          )}
        </motion.div>
        <div className="text-center mt-12">
          <p className="text-gray-400">Looking for safe ways to get Robux? Visit our <Link to="/how-to-get-free-robux-legally-2025" className="text-purple-400 hover:underline">Earn Robux section</Link>.</p>
        </div>
      </section>
    </main>
  );
};

export default Generadores;
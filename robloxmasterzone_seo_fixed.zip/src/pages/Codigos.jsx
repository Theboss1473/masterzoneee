import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { promoCodeCategories } from '@/data/promo_codes_data';
import JsonLd from '@/components/JsonLd';
import { Copy, ExternalLink } from 'lucide-react';
import { useToast } from "@/components/ui/use-toast";

const Codigos = () => {
    const canonicalUrl = `https://robloxmasterzone.com/active-roblox-promo-codes`;
    const pageTitle = "Active Roblox Promo Codes List (August 2025) - All Working Codes";
    const pageDescription = "The complete list of all working and active Roblox promo codes for August 2025. Get free items, accessories, and effects for your avatar. Updated daily!";
    const { toast } = useToast();

    const pageSchema = {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": pageTitle,
      "description": pageDescription,
      "url": canonicalUrl,
      "publisher": {
        "@type": "Organization",
        "name": "RobloxMasterZone"
      }
    };

    const handleCopy = (code) => {
        navigator.clipboard.writeText(code);
        toast({
            title: "Code Copied!",
            description: `The code "${code}" has been copied to your clipboard.`,
            variant: "success",
        });
    };

    return (
        <main className="dark">
            <Helmet>
                <title>{pageTitle}</title>
                <meta name="description" content={pageDescription} />
                <meta name="robots" content="index, follow" />
                <link rel="canonical" href={canonicalUrl} />
                <meta property="og:title" content={pageTitle} />
                <meta property="og:description" content={pageDescription} />
                <meta property="og:type" content="website" />
                <meta property="og:url" content={canonicalUrl} />
                <meta property="og:image" content="https://robloxmasterzone.com/og-image.jpg" />
                <meta name="twitter:card" content="summary_large_image" />
                <meta name="twitter:title" content={pageTitle} />
                <meta name="twitter:description" content={pageDescription} />
                <meta name="twitter:image" content="https://robloxmasterzone.com/og-image.jpg" />
            </Helmet>
            <JsonLd data={pageSchema} />
            <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
                <motion.div
                    initial={{ opacity: 0, y: -30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7 }}
                >
                    <h1 className="text-4xl md:text-5xl font-orbitron font-extrabold text-center text-green-400 neon-text-green mb-4">
                        Active Roblox Promo Codes (August 2025)
                    </h1>
                    <p className="text-lg text-gray-300 text-center max-w-3xl mx-auto mb-12">
                        Here is the complete list of all active codes to get free items for your avatar. We verify these codes daily to ensure they work.
                    </p>
                </motion.div>

                <div className="space-y-12">
                    {promoCodeCategories.map((category, index) => (
                        <motion.section 
                            key={index}
                            initial={{ opacity: 0, x: -50 }}
                            whileInView={{ opacity: 1, x: 0 }}
                            viewport={{ once: true, amount: 0.2 }}
                            transition={{ duration: 0.5, delay: index * 0.1 }}
                            aria-labelledby={`category-title-${index}`}
                        >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-6">
                                <div className="flex items-center mb-4 sm:mb-0">
                                    <category.icon className="w-10 h-10 text-purple-400 mr-4" aria-hidden="true"/>
                                    <div>
                                        <h2 id={`category-title-${index}`} className="text-3xl font-orbitron text-white">{category.title}</h2>
                                        <p className="text-gray-400 max-w-2xl">{category.description}</p>
                                    </div>
                                </div>
                                <Button asChild variant="neon" size="sm">
                                    <a href={category.redeemUrl} target="_blank" rel="noopener noreferrer">
                                        Redeem Here <ExternalLink className="ml-2 h-4 w-4" />
                                    </a>
                                </Button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                                {category.codes.map((promo, pIndex) => (
                                    <motion.div
                                        key={pIndex}
                                        initial={{ opacity: 0, scale: 0.9 }}
                                        whileInView={{ opacity: 1, scale: 1 }}
                                        viewport={{ once: true, amount: 0.5 }}
                                        transition={{ duration: 0.3, delay: pIndex * 0.05 }}
                                        className="bg-gray-900/50 p-4 rounded-lg border-2 border-purple-800/50 flex flex-col justify-between items-center text-center"
                                    >
                                        <p className="text-lg text-gray-300 mb-2">Unlocks the <span className="font-semibold text-white">{promo.item}</span></p>
                                        <div className="bg-black/50 border border-gray-700 rounded-md px-4 py-2 flex items-center justify-center w-full mb-3">
                                            <span className="font-mono text-xl text-green-400 tracking-widest">{promo.code}</span>
                                        </div>
                                        <Button
                                            variant="secondary"
                                            className="w-full bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500 text-purple-300 hover:text-white"
                                            onClick={() => handleCopy(promo.code)}
                                            aria-label={`Copy code ${promo.code}`}
                                        >
                                            <Copy className="mr-2 h-4 w-4"/> Copy Code
                                        </Button>
                                    </motion.div>
                                ))}
                            </div>
                        </motion.section>
                    ))}
                </div>
            </section>
        </main>
    );
};

export default Codigos;
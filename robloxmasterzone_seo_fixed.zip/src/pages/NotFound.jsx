import React from 'react';
import { Helmet } from 'react-helmet-async';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

const NotFound = () => {
  return (
    <main className="dark">
      <Helmet>
        <title>404 - Page Not Found | RobloxMasterZone</title>
        <meta name="description" content="The page you are looking for does not exist or has been moved." />
        <meta name="robots" content="noindex, follow" />
      </Helmet>
      <div className="min-h-[60vh] flex flex-col items-center justify-center text-center px-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{
            duration: 0.5,
            type: "spring",
            stiffness: 100,
          }}
        >
          <h1 className="text-8xl md:text-9xl font-orbitron font-extrabold text-purple-500 neon-text">404</h1>
          <p className="text-2xl md:text-3xl font-orbitron font-bold text-white mt-4">Page Not Found</p>
          <p className="text-gray-400 mt-2 max-w-md">
            Oops! The page you're looking for seems to have gotten lost in the metaverse.
          </p>
          <Button asChild variant="neon" size="lg" className="mt-8">
            <Link to="/">
              Return to Homepage
            </Link>
          </Button>
        </motion.div>
      </div>
    </main>
  );
};

export default NotFound;
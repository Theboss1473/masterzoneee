import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { useParams, Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import NotFound from '@/pages/NotFound';
import JsonLd from '@/components/JsonLd';
import { allArticles } from '@/data/articles';

const Articulo = () => {
  const { slug } = useParams();
  const location = useLocation();
  const [currentArticle, setCurrentArticle] = useState(undefined);

  useEffect(() => {
    const article = allArticles.find(a => a.slug === slug);
    setCurrentArticle(article || null);
  }, [slug]);


  if (currentArticle === undefined) {
    return <div className="dark bg-black text-white flex justify-center items-center h-screen text-2xl font-orbitron">Loading Article...</div>;
  }
  
  if (currentArticle === null) {
    return <NotFound />;
  }

  const { title, description, content, category, image, date } = currentArticle;
  const canonicalUrl = `https://robloxmasterzone.com/article/${slug}`;
  const pageTitle = `${title} | RobloxMasterZone Guide`;
  const metaDescription = description || `In-depth guide for ${title}. Discover tips, tricks, and secrets to master this aspect of Roblox. Updated for August 2025.`;
  const ogImageUrl = image || 'https://robloxmasterzone.com/og-image.jpg';
  const altText = `Main image for the article titled: ${title}`;

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": title,
    "description": metaDescription,
    "image": ogImageUrl,
    "author": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    },
    "publisher": {
      "@type": "Organization",
      "name": "RobloxMasterZone",
      "logo": {
        "@type": "ImageObject",
        "url": "https://robloxmasterzone.com/favicon.svg"
      }
    },
    "datePublished": date || "2025-08-06",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": canonicalUrl
    }
  };

  const getBackLink = () => {
    return location.state?.from || '/';
  }

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={metaDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={metaDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:image" content={ogImageUrl} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={metaDescription} />
        <meta name="twitter:image" content={ogImageUrl} />
      </Helmet>
      <JsonLd data={articleSchema} />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-16">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <div className="mb-8">
            <Button asChild variant="outline" className="border-purple-500 text-purple-300 hover:bg-purple-500/10 hover:text-white">
              <Link to={getBackLink()} aria-label="Go back to previous page">
                <ArrowLeft className="mr-2 h-4 w-4" /> Back to list
              </Link>
            </Button>
          </div>

          <article>
            <header className="mb-8">
              <span className="text-purple-400 font-orbitron font-bold">{category}</span>
              <h1 className="text-4xl md:text-5xl font-orbitron font-extrabold text-white mt-2 mb-4 leading-tight neon-text">{title}</h1>
              <p className="text-lg text-gray-400">{description}</p>
            </header>

            {image && (
              <section className="mb-8 rounded-lg overflow-hidden border-2 border-purple-700 shadow-lg shadow-purple-500/20">
                <img loading="lazy" className="w-full h-auto object-cover" alt={altText} src={image} />
              </section>
            )}

            <section 
              className="prose prose-invert prose-lg max-w-none text-gray-300 prose-h2:text-3xl prose-h2:font-orbitron prose-h2:text-green-400 prose-h3:text-2xl prose-h3:font-orbitron prose-h3:text-purple-400 prose-h4:text-xl prose-h4:font-orbitron prose-h4:text-white prose-a:text-green-400 hover:prose-a:text-green-300 prose-strong:text-white"
              dangerouslySetInnerHTML={{ __html: content }}
            />
          </article>
        </motion.div>
      </div>
    </main>
  );
};

export default Articulo;
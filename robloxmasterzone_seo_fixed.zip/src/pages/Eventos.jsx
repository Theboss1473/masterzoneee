import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { allArticles } from '@/data/articles';
import ArticleCard from '@/components/ArticleCard';
import JsonLd from '@/components/JsonLd';
import { Link } from 'react-router-dom';

const Eventos = () => {
  const canonicalUrl = `https://robloxmasterzone.com/latest-roblox-events-and-rewards`;
  const pageTitle = "All Roblox Events & Reward Guides (August 2025)";
  const pageDescription = "Find all current and upcoming Roblox events for August 2025. Our guides show you how to join and complete events to get exclusive free items and rewards.";

  const eventosArticles = allArticles.filter(a => a.categoryKey === 'Events');

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    "name": pageTitle,
    "description": pageDescription,
    "url": canonicalUrl,
    "publisher": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    }
  };

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={canonicalUrl} />
        <meta property="og:image" content="https://robloxmasterzone.com/og-image.jpg" />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
        <meta name="twitter:image" content="https://robloxmasterzone.com/og-image.jpg" />
      </Helmet>
      <JsonLd data={pageSchema} />
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
        >
          <h1 className="text-4xl md:text-5xl font-orbitron font-extrabold text-center text-white neon-text mb-4">
            Guides for All Roblox Events
          </h1>
          <p className="text-lg text-gray-300 text-center max-w-3xl mx-auto mb-12">
            Don't miss out on any official Roblox event. Here are the guides to get all the free items and rewards for August 2025.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {eventosArticles.length > 0 ? (
            eventosArticles.map((article, index) => (
              <ArticleCard key={index} article={article} />
            ))
          ) : (
            <p className="text-center text-gray-400 col-span-full">No articles found in this category.</p>
          )}
        </motion.div>
        <div className="text-center mt-12">
          <p className="text-gray-400">Want to see what's coming next? Check our <Link to="/roblox-news-and-updates" className="text-purple-400 hover:underline">News section</Link>.</p>
        </div>
      </section>
    </main>
  );
};

export default Eventos;
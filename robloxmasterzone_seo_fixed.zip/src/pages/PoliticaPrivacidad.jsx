import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import JsonLd from '@/components/JsonLd';

const PoliticaPrivacidad = () => {
  const canonicalUrl = `https://robloxmasterzone.com/privacy-policy`;
  const pageTitle = "Privacy Policy for RobloxMasterZone Website";
  const pageDescription = "Read the official privacy policy for RobloxMasterZone. Learn how we collect, use, and protect your data when you visit our site for Roblox guides and news.";

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Privacy Policy for RobloxMasterZone",
    "description": "Our privacy policy details how user data is handled, the use of cookies, and our commitment to protecting your privacy.",
    "author": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    },
    "datePublished": "2025-08-06",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": canonicalUrl
    }
  };

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="article" />
        <meta property="og:url" content={canonicalUrl} />
        <meta name="twitter:card" content="summary" />
        <meta name="twitter:title" content={pageTitle} />
        <meta name="twitter:description" content={pageDescription} />
      </Helmet>
      <JsonLd data={pageSchema} />
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="max-w-4xl mx-auto bg-gray-900/50 p-8 rounded-lg border-2 border-purple-800/50"
        >
          <h1 className="text-3xl md:text-4xl font-orbitron font-extrabold text-center text-white neon-text mb-8">
            Our Website Privacy Policy
          </h1>
          
          <article className="prose prose-invert prose-lg max-w-none text-gray-300">
            <p><strong>Last Updated: August 06, 2025</strong></p>
            <p>Your privacy is important to us. It is RobloxMasterZone's policy to respect your privacy regarding any information we may collect from you across our website, https://robloxmasterzone.com, and other sites we own and operate.</p>
            
            <h2 className="text-2xl font-bold text-purple-400">Information We Collect</h2>
            <p>We only ask for personal information when we truly need it to provide a service to you (for example, when you use our contact form). We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we’re collecting it and how it will be used.</p>
            
            <h2 className="text-2xl font-bold text-purple-400">How We Use Your Information</h2>
            <p>We only retain collected information for as long as necessary to provide you with your requested service. What data we store, we’ll protect within commercially acceptable means to prevent loss and theft, as well as unauthorized access, disclosure, copying, use or modification.</p>
            
            <h2 className="text-2xl font-bold text-purple-400">Cookies and Third-Party Services</h2>
            <p>Our website may use cookies to enhance user experience. We also use third-party services like Google AdSense, which use cookies to serve ads based on a user's prior visits to our website or other websites. You can opt out of personalized advertising by visiting Google's Ads Settings.</p>
            
            <h2 className="text-2xl font-bold text-purple-400">Links to Other Sites</h2>
            <p>Our website may link to external sites that are not operated by us. Please be aware that we have no control over the content and practices of these sites, and cannot accept responsibility or liability for their respective privacy policies.</p>
            
            <p>Your continued use of our website will be regarded as acceptance of our practices around privacy and personal information. If you have any questions about how we handle user data and personal information, feel free to contact us.</p>
          </article>
          <div className="text-center mt-8">
             <p className="text-gray-400">For more information, see our <Link to="/legal-notice" className="text-purple-400 hover:underline">Legal Notice</Link>.</p>
          </div>
        </motion.div>
      </section>
    </main>
  );
};

export default PoliticaPrivacidad;
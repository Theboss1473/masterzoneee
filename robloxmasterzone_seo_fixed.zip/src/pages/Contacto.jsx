import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Mail, AlertTriangle } from 'lucide-react';
import JsonLd from '@/components/JsonLd';

const Contacto = () => {
  const canonicalUrl = `https://robloxmasterzone.com/contact-us`;
  const pageTitle = "Contact RobloxMasterZone for Support & Inquiries";
  const pageDescription = "Get in touch with the RobloxMasterZone team. Use our contact information for support, suggestions, or any questions you have about our Roblox guides and content.";

  const pageSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "headline": "Contact Us",
    "description": "Contact information for RobloxMasterZone for support, questions, and suggestions.",
    "author": {
      "@type": "Organization",
      "name": "RobloxMasterZone"
    },
    "datePublished": "2025-08-06",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": canonicalUrl
    }
  };

  return (
    <main className="dark">
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <meta name="robots" content="index, follow" />
        <link rel="canonical" href={canonicalUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={pageDescription} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={canonicalUrl} />
        <meta name="twitter:card" content="summary" />
      </Helmet>
      <JsonLd data={pageSchema} />
      <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto text-center"
        >
          <Mail className="mx-auto h-16 w-16 text-purple-400" aria-hidden="true" />
          <h1 className="text-4xl md:text-5xl font-orbitron font-extrabold text-white mt-4 mb-4 neon-text">
            Get in Touch With Our Team
          </h1>
          <p className="text-lg text-gray-400 mb-8">
            If you have questions, suggestions, or need to report an issue, please don't hesitate to reach out.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="max-w-2xl mx-auto bg-gray-900/50 rounded-lg border-2 border-purple-800/50 p-8"
        >
          <section aria-labelledby="contact-email-heading">
            <h2 id="contact-email-heading" className="sr-only">Contact Email</h2>
            <div className="text-center">
              <p className="text-gray-300 mb-4">The best way to contact us is via email:</p>
              <a 
                href="mailto:jetibinalo@gmail.com" 
                className="text-2xl font-orbitron font-bold text-green-400 neon-green-text-light break-all"
              >
                jetibinalo@gmail.com
              </a>
            </div>
          </section>

          <section className="mt-8 border-t border-purple-800/50 pt-6" aria-labelledby="common-issues-heading">
            <h2 id="common-issues-heading" className="text-2xl font-orbitron font-bold text-white text-center mb-4">Common Issues</h2>
            <div className="flex items-start space-x-4 p-4 bg-yellow-900/20 border border-yellow-500/50 rounded-lg">
              <AlertTriangle className="h-8 w-8 text-yellow-400 flex-shrink-0 mt-1" aria-hidden="true" />
              <div>
                <h3 className="font-bold text-yellow-300">Loading or Display Problems</h3>
                <p className="text-yellow-200/80 text-sm">
                  If the page doesn't load correctly or images are missing, try refreshing the page (Ctrl+R or Cmd+R). If the problem persists, it might be a temporary issue we are already fixing.
                </p>
              </div>
            </div>
             <div className="flex items-start space-x-4 p-4 bg-blue-900/20 border border-blue-500/50 rounded-lg mt-4">
              <AlertTriangle className="h-8 w-8 text-blue-400 flex-shrink-0 mt-1" aria-hidden="true" />
              <div>
                <h3 className="font-bold text-blue-300">Incorrect or Outdated Content</h3>
                <p className="text-blue-200/80 text-sm">
                  We work hard to keep everything up-to-date, but if you find a code that doesn't work or incorrect information, we'd appreciate you letting us know via email!
                </p>
              </div>
            </div>
          </section>
        </motion.div>
      </section>
    </main>
  );
};

export default Contacto;
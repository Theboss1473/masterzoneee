import { Gift, MousePointerClick, Gamepad2 } from 'lucide-react';

export const promoCodeCategories = [
  {
    title: "Website Promo Codes",
    description: "These codes are redeemed on the official Roblox website. They are usually released during official events or social media promotions.",
    icon: MousePointerClick,
    redeemUrl: "https://www.roblox.com/promocodes",
    codes: [
      { code: "SPIDERCOLA", item: "Spider Cola shoulder pet" },
      { code: "TWEETROBLOX", item: "'The Bird Says' shoulder pet" },
      { code: "ROBLOXEDU2025", item: "Education-themed back accessory" },
      { code: "FREEAMAZONFOX2025", item: "Arctic Fox head accessory" }
    ]
  },
  {
    title: "Island of Move Codes",
    description: "These codes must be redeemed within the 'Island of Move' game. They provide exclusive avatar items related to movement and style.",
    icon: Gamepad2,
    redeemUrl: "https://www.roblox.com/games/391384957/Island-of-Move",
    codes: [
      { code: "STRIKEAPOSE", item: "Hustle Hat" },
      { code: "DIY", item: "Kinetic Staff" },
      { code: "WORLDALIVE", item: "Crystalline Companion" },
      { code: "GETMOVING", item: "Speedy Shades" },
      { code: "VICTORYLAP", item: "Cardio Cans" }
    ]
  },
  {
    title: "Mansion of Wonder Codes",
    description: "Redeem these codes inside the 'Mansion of Wonder' experience to get amazing special effects and accessories for your avatar.",
    icon: Gift,
    redeemUrl: "https://www.roblox.com/games/6596032169/Mansion-of-Wonder",
    codes: [
      { code: "GLIMMER", item: "Slime Head accessory" },
      { code: "THINGSGOBOOM", item: "Ghastly Aura waist effect" },
      { code: "PARTICLEWIZARD", item: "Tome of the Magus shoulder accessory" },
      { code: "FXARTIST", item: "Artist Backpack" },
      { code: "BOARDWALK", item: "Ring of Flames waist effect" }
    ]
  }
];
import { article as codigosRoblox } from './articles/codigos-roblox_fr.js';
import { article as conseguirRobux } from './articles/conseguir-robux_fr.js';
import { article as mejoresJuegos } from './articles/mejores-juegos_fr.js';
import { article as eventoTheHunt } from './articles/evento-the-hunt_fr.js';
import { article as accesoriosGratis } from './articles/accesorios-gratis_fr.js';
import { article as generadoresEstafa } from './articles/generadores-estafa_fr.js';
import { article as optimizarRendimiento } from './articles/optimizar-rendimiento_fr.js';
import { article as robloxPremium } from './articles/roblox-premium_fr.js';
import { article as historiaRoblox } from './articles/historia-roblox_fr.js';
import { article as trucosConstruccion } from './articles/trucos-construccion_fr.js';
import { article as protegerCuenta } from './articles/proteger-cuenta_fr.js';

export const articles = [
  codigosRoblox,
  conseguirRobux,
  mejoresJuegos,
  eventoTheHunt,
  accesoriosGratis,
  generadoresEstafa,
  optimizarRendimiento,
  robloxPremium,
  historiaRoblox,
  trucosConstruccion,
  protegerCuenta,
];
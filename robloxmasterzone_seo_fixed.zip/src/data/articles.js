import { articles as newsArticles } from '@/data/news_articles.js';
import { articles as guidesArticles } from '@/data/guides_articles.js';
import { articles as robuxGratisAgosto2025 } from '@/data/robux_gratis_agosto_2025.js';

export const allArticles = [
  ...newsArticles,
  ...guidesArticles,
  ...robuxGratisAgosto2025
].sort((a, b) => new Date(b.date || '1970-01-01') - new Date(a.date || '1970-01-01'));
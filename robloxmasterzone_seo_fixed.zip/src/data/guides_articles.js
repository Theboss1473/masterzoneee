import { article as conseguirRobux } from '@/data/articles/conseguir-robux_en.js';
import { article as protegerCuenta } from '@/data/articles/proteger-cuenta_en.js';
import { article as mejoresJuegos } from '@/data/articles/mejores-juegos_en.js';
import { article as accesoriosGratis } from '@/data/articles/accesorios-gratis_en.js';
import { article as codigosRoblox } from '@/data/articles/codigos-roblox_en.js';
import { article as eventoTheHunt } from '@/data/articles/evento-the-hunt_en.js';
import { article as generadoresEstafa } from '@/data/articles/generadores-estafa_en.js';
import { article as historiaRoblox } from '@/data/articles/historia-roblox_en.js';
import { article as optimizarRendimiento } from '@/data/articles/optimizar-rendimiento_en.js';
import { article as robloxPremium } from '@/data/articles/roblox-premium_en.js';
import { article as trucosConstruccion } from '@/data/articles/trucos-construccion_en.js';

export const articles = [
  { ...conseguirRobux, thematic: 'robux_codes' },
  { ...protegerCuenta, thematic: 'gaming_tips' },
  { ...mejoresJuegos, thematic: 'gaming_tips' },
  { ...generadoresEstafa, thematic: 'robux_codes' },
  { ...robloxPremium, thematic: 'robux_codes' },
  { ...optimizarRendimiento, thematic: 'gaming_tips' },
  { ...accesoriosGratis, thematic: 'creation_avatars' },
  { ...codigosRoblox, thematic: 'robux_codes' },
  { ...eventoTheHunt, thematic: 'gaming_tips' },
  { ...historiaRoblox, thematic: 'gaming_tips' },
  { ...trucosConstruccion, thematic: 'creation_avatars' },
].sort((a, b) => new Date(b.date || '1970-01-01') - new Date(a.date || '1970-01-01'));
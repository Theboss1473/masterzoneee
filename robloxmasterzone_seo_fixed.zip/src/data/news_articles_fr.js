import { article as nuevasFuncionesStudio } from '@/data/articles/news/nuevas-funciones-studio_fr.jsx';
import { article as colaboracionesMarcas } from '@/data/articles/news/colaboraciones-marcas_fr.jsx';
import { article as eventosPopulares } from '@/data/articles/news/eventos-populares_fr.jsx';
import { article as impactoActualizaciones } from '@/data/articles/news/impacto-actualizaciones_fr.jsx';
import { article as cambiosPoliticas } from '@/data/articles/news/cambios-politicas_fr.jsx';
import { article as experienciasVisitadas } from '@/data/articles/news/experiencias-visitadas_fr.jsx';
import { article as criticasComunidad } from '@/data/articles/news/criticas-comunidad_fr.jsx';
import { article as avancesMonetizacion } from '@/data/articles/news/avances-monetizacion_fr.jsx';
import { article as herramientasDesarrolladores } from '@/data/articles/news/herramientas-desarrolladores_fr.jsx';
import { article as rumoresFiltraciones } from '@/data/articles/news/rumores-filtraciones_fr.jsx';

export const articles = [
  nuevasFuncionesStudio,
  colaboracionesMarcas,
  eventosPopulares,
  impactoActualizaciones,
  cambiosPoliticas,
  experienciasVisitadas,
  criticasComunidad,
  avancesMonetizacion,
  herramientasDesarrolladores,
  rumoresFiltraciones,
];
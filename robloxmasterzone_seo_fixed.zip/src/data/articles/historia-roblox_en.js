export const article = {
  slug: 'historia-secreta-de-roblox',
  title: 'The Secret History of Roblox: From Physics Simulator to Metaverse',
  description: 'Travel back in time to discover the origins of Roblox. Did you know it wasn\'t always a game? Learn about its incredible evolution.',
  image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1ac6c1b6-27b8-4b8e-b4ac-c5baf54fc1e4/5dbf7f5d9b782189abbf5aea9e1a35c4.jpg',
  category: 'News',
  categoryKey: 'Novedades',
  content: `
  <h2 class="text-3xl font-orbitron font-bold text-green-400 mb-4">From DynaBlocks to Metaverse: The Fascinating History of Roblox</h2>
  <p class="mb-6 text-lg text-gray-300">Today, Roblox is a digital entertainment giant, a platform with millions of games and a global community. But have you ever wondered how it all began? The story of Roblox is an incredible journey that dates back long before its official launch in 2006. It didn't start as a game, but as an educational physics simulation tool.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">The Origins: Interactive Physics (1989)</h3>
  <p class="mb-4 text-gray-400">The story of Roblox begins with its two founders, David Baszucki and Erik Cassel. In the late 1980s, Baszucki developed "Interactive Physics," a simulation program that allowed students and teachers to model physics experiments in a 2D environment. They could create levers, ramps, collisions, and see how the laws of physics acted on their creations. This program was a success in the educational field.</p>
  <p class="mb-4 text-gray-400">Baszucki noticed something fascinating: students weren't just using the program for homework. They started experimenting, building crazy things, and creating simple games within the simulator, like crashing cars or collapsing buildings. He saw the potential for a platform where people could create and share their own interactive 3D experiences. The seed of Roblox had been planted.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">The Birth of "DynaBlocks" (2004)</h3>
  <p class="mb-4 text-gray-400">After selling his company, Baszucki teamed up with Erik Cassel, who had worked with him on Interactive Physics, to start a new project. In 2004, they began developing a new platform. The prototype's code name was "DynaBlocks." This name reflected the dynamic and block-based nature of the platform.</p>
  <p class="mb-4 text-gray-400">The early days were pure experimentation. The first version of DynaBlocks was very primitive, with simple graphics and limited functionality. However, the core idea was already there: a virtual universe where users not only played but also created the games. The physics engine remained a fundamental part, allowing for complex and realistic creations.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">The Name Change and Launch (2005-2006)</h3>
  <p class="mb-4 text-gray-400">In 2005, the name "DynaBlocks" was changed to "Roblox," a portmanteau of the words "robots" and "blocks." The team felt it was a catchier andmore representative name. After years of development and beta testing, Roblox was officially launched to the public in September 2006.</p>
  <p class="mb-4 text-gray-400">In its early days, Roblox was very different from what we know today. The community was small, and the creation tool, Roblox Studio, was much more basic. There were no Robux; the virtual currency was called "Roblox Points." Despite its simplicity, the platform began to attract a community of passionate creators who saw its potential.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">The Evolution into a Metaverse</h3>
  <p class="mb-4 text-gray-400">Over the years, Roblox evolved at a steady pace:</p>
  <ul class="list-disc list-inside mb-6 space-y-2 text-gray-300">
    <li><strong>2007:</strong> The "Builders Club" (the forerunner of Premium) and customizable clothing were introduced.</li>
    <li><strong>2012:</strong> Roblox arrived on iOS devices, massively expanding its player base.</li>
    <li><strong>2013:</strong> The "Developer Exchange" (DevEx) program was introduced, allowing developers to exchange earned Robux for real money. This professionalized game creation on the platform.</li>
    <li><strong>2015 onwards:</strong> It launched on Xbox, the graphics engine was improved, support for Virtual Reality (VR) was introduced, and it expanded to more platforms.</li>
  </ul>

  <p class="mt-6 text-lg text-gray-300">Baszucki's vision, inspired by those students playing with a physics simulator, has become one of the largest entertainment platforms in the world. It is a testament to the power of creativity and community. The next time you enter a game on Roblox, remember that you are participating in a legacy that began more than 30 years ago with a simple physics simulation.</p>
`
};
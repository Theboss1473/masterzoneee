export const article = {
        slug: 'trucos-construccion-roblox-studio',
        title: '5 Trucos de Construcción en Roblox Studio para Principiantes',
        description: '¿Quieres empezar a crear tus propios juegos? Aprende estos 5 trucos esenciales de Roblox Studio para construir como un profesional desde el primer día.',
        image: 'User creating a complex structure in Roblox Studio',
        category: 'Trucos',
        content: `
        <h2 class="text-3xl font-orbitron font-bold text-green-400 mb-4">Construye como un Pro: 5 Trucos Esenciales de Roblox Studio para Novatos</h2>
        <p class="mb-6 text-lg text-gray-300">Entrar a Roblox Studio por primera vez puede ser abrumador. Hay botones por todas partes y un mundo vacío esperando a ser llenado. ¡Pero no te preocupes! Crear tus propias experiencias no es tan difícil como parece. Para ayudarte a empezar con el pie derecho, hemos recopilado 5 trucos fundamentales que todo constructor principiante debería conocer. ¡Dominar estos conceptos te ahorrará horas de frustración y mejorará la calidad de tus creaciones al instante!</p>
    
        <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">1. Domina la Herramienta de Mover con Incrementos</h3>
        <p class="mb-4 text-gray-400">Cuando mueves o escalas una pieza (Part), puede que notes que se mueve a saltos. Esto se debe a los "incrementos". En la pestaña "MODEL", verás una casilla llamada "Move" con un número (generalmente 1 stud). Esto significa que cada vez que mueves la pieza, se desplazará exactamente 1 stud. Esto es útil para alinear cosas perfectamente.</p>
        <p class="mb-4 text-gray-400"><strong>El Truco:</strong> A veces necesitas un control más preciso. Puedes cambiar este número a un valor más pequeño (como 0.1 o 0.05) para movimientos más finos, o desactivar la casilla para un movimiento completamente libre. <strong class="text-white">¡No olvides volver a activarlo cuando necesites alinear piezas de nuevo!</strong> Lo mismo aplica para la rotación ("Rotate"), que por defecto está en 45 grados.</p>
    
        <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">2. Usa Anclas (Anchors) para Evitar el Caos</h3>
        <p class="mb-4 text-gray-400">Imagina que construyes una casa increíble, pieza por pieza. Inicias el juego para probarla y... ¡toda la casa se derrumba en un montón de bloques! Esto pasa porque las piezas no están "ancladas". Por defecto, las piezas en Roblox se ven afectadas por la gravedad y la física.</p>
        <p class="mb-4 text-gray-400"><strong>El Truco:</strong> Selecciona una pieza o un grupo de piezas que no quieras que se muevan (como el suelo, las paredes, etc.). En la pestaña "HOME" o "MODEL", busca un icono que parece un ancla y haz clic en él. La propiedad "Anchored" de la pieza se activará. Ahora, esa pieza quedará fija en el aire, inmune a la gravedad. <strong class="text-white">Anclar todo lo que deba ser estático es una de las prácticas más importantes en la construcción.</strong></p>
    
        <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">3. Agrupa (Group) tus Creaciones</h3>
        <p class="mb-4 text-gray-400">Cuando construyes algo complejo, como un coche o un árbol, estará compuesto por muchas piezas individuales. Moverlo o modificarlo puede ser una pesadilla, ya que tendrías que seleccionar cada pieza una por una.</p>
        <p class="mb-4 text-gray-400"><strong>El Truco:</strong> Mantén presionada la tecla Shift y haz clic en todas las piezas que forman tu objeto. Una vez seleccionadas todas, haz clic derecho y elige "Group" (o presiona Ctrl + G). Esto las convertirá en un solo "Model" en la ventana del Explorador. Ahora puedes mover, rotar o escalar todo el objeto como si fuera una sola pieza, manteniendo todas las partes en su posición relativa. ¡Es un salvavidas para la organización!</p>
    
        <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">4. Desactiva "Collisions" para un Posicionamiento Perfecto</h3>
        <p class="mb-4 text-gray-400">¿Has intentado meter una pieza dentro de otra y has visto que se empujan entre sí? Esto es por la detección de colisiones, que evita que las piezas se atraviesen. Es útil, pero a veces necesitas que lo hagan.</p>
        <p class="mb-4 text-gray-400"><strong>El Truco:</strong> En la pestaña "MODEL", verás una opción llamada "Collisions". Si la desactivas, podrás mover piezas a través de otras libremente. Esto es esencial para añadir detalles finos, como poner una ventana dentro de una pared o crear formas complejas superponiendo varias piezas. <strong class="text-white">Recuerda volver a activarla cuando termines para evitar colocar piezas accidentalmente unas dentro de otras.</strong></p>
    
        <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">5. La Ventana de Propiedades es tu Mejor Amiga</h3>
        <p class="mb-4 text-gray-400">Cada pieza en tu juego tiene un montón de propiedades que puedes cambiar, mucho más allá del color y el material. Puedes cambiar su transparencia, si proyecta sombras, si los jugadores pueden atravesarla (CanCollide) y mucho más.</p>
        <p class="mb-4 text-gray-400"><strong>El Truco:</strong> Ve a la pestaña "VIEW" y asegúrate de que tanto el "Explorer" como las "Properties" están activados. Ahora, cada vez que selecciones una pieza, la ventana de Propiedades te mostrará todo lo que puedes modificar. Experimenta cambiando valores. ¿Quieres hacer una pared invisible pero sólida? Pon la Transparencia en 1 y deja CanCollide activado. ¿Quieres hacer una ventana que se pueda atravesar? Pon CanCollide en desactivado. Explorar esta ventana te abrirá un mundo de posibilidades.</p>
    
        <p class="mt-6 text-lg text-gray-300">Con estos cinco trucos, ya tienes una base sólida para empezar a construir en Roblox Studio. La clave es practicar y experimentar. ¡No tengas miedo de probar cosas nuevas y ver qué pasa! Abre un proyecto en blanco y empieza a aplicar estos consejos. ¡Te sorprenderá lo rápido que mejoras!</p>
      `
      };
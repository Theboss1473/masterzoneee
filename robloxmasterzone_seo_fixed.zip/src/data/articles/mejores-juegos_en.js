export const article = {
  slug: 'mejores-juegos-roblox-para-jugar-con-amigos',
  title: 'The 10 Best Roblox Games to Play with Friends',
  description: 'Bored of playing alone? Here is a list of the most fun and cooperative Roblox games to enjoy with company.',
  image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1ac6c1b6-27b8-4b8e-b4ac-c5baf54fc1e4/c6452e41b583471b9435ddbe093033e3.jpg',
  category: 'News',
  categoryKey: 'Novedades',
  content: `
  <h2 class="text-3xl font-orbitron font-bold text-green-400 mb-4">Top 10 Roblox Games for Limitless Fun with Friends</h2>
  <p class="mb-6 text-lg text-gray-300">Roblox is an incredibly social platform, and its true magic often unfolds when you play with friends. Whether you're looking for epic adventures, intense competitions, or just a good time, there's a game for every group. Here is our selection of the 10 best games to enjoy together.</p>

  <ol class="space-y-8">
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">1. Adopt Me!</h3>
      <p class="text-gray-400">An undisputed classic. In Adopt Me!, you and your friends can raise adorable pets, from dogs and cats to legendary dragons and unicorns. You can decorate your houses, trade pets, and explore a vibrant world full of secrets and seasonal events. It's a relaxing and perfect game for socializing.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">2. Blox Fruits</h3>
      <p class="text-gray-400">Inspired by the famous anime "One Piece," Blox Fruits is a massive RPG adventure. Team up with your friends, sail the seas, fight fearsome bosses, and search for the powerful Devil Fruits that grant incredible abilities. Cooperation is key to defeating the strongest enemies and becoming the most feared pirates.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">3. Murder Mystery 2</h3>
      <p class="text-gray-400">Test your deduction and deception skills. In each round, one player is the murderer, another is the sheriff, and the rest are innocents. The murderer must eliminate everyone without being discovered, the sheriff must stop them, and the innocents must survive. Laughter and tension are guaranteed as you try to figure out who the traitor is.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">4. Tower of Hell</h3>
      <p class="text-gray-400">Think you have good parkour skills? Tower of Hell will put you to the test. It's a race against time to reach the top of a procedurally generated tower filled with challenging obstacles. There are no checkpoints. Compete to see who reaches the top first or help each other overcome the most difficult sections. It's chaotic, frustrating, and extremely fun.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">5. Brookhaven RP</h3>
      <p class="text-gray-400">For roleplay lovers, Brookhaven is paradise. It's a virtual city where you can be whoever you want: a police officer, a firefighter, a doctor, or just a citizen. Buy houses, drive luxury cars, and create your own stories with friends. The possibilities are endless.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">6. Arsenal</h3>
      <p class="text-gray-400">If you're looking for fast-paced action, Arsenal is your game. It's a fast-paced first-person shooter where the weapon changes with each elimination. The gameplay is chaotic and addictive. Team up or compete in a free-for-all to see who dominates the battlefield.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">7. Piggy</h3>
      <p class="text-gray-400">A horror and survival game that combines puzzles with intense chases. You and your friends must solve puzzles to escape from different maps while being chased by the terrifying Piggy. Communication is essential to find keys, unlock doors, and survive together.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">8. Work at a Pizza Place</h3>
      <p class="text-gray-400">A very entertaining cooperative work simulator. Take on different roles in a pizzeria: cook, cashier, delivery person. Coordinate your efforts to satisfy customers and earn money to upgrade your houses. It's a surprisingly deep and fun team game.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">9. Epic Minigames</h3>
      <p class="text-gray-400">Can't decide what to play? Epic Minigames throws you into a series of fast and varied minigames, one after another. From platform races to survival battles, you'll never know what to expect. Compete for points and see who is the ultimate minigame champion.</p>
    </li>
    <li>
      <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">10. Doors</h3>
      <p class="text-gray-400">A high-quality cooperative horror experience. Navigate a haunted hotel full of terrifying entities. Each door presents a new challenge, and each entity requires a different strategy to survive. The atmosphere is incredible, and playing it with friends makes the scares even more memorable. Be sure to use headphones!</p>
    </li>
  </ol>
  <p class="mt-8 text-lg text-gray-300">So gather your team, pick a game from this list, and get ready for hours of fun. Roblox is better when shared!</p>
`
};
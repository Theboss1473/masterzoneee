export const article = {
        slug: 'mejores-juegos-roblox-para-jugar-con-amigos',
        title: 'Los 10 Mejores Juegos de Roblox para Jugar con Amigos',
        description: '¿Aburrido de jugar solo? Aquí tienes una lista de los juegos más divertidos y cooperativos de Roblox para disfrutar en compañía.',
        image: 'Group of Roblox characters playing together',
        category: 'Novedades',
        content: `
        <h2 class="text-3xl font-orbitron font-bold text-green-400 mb-4">Top 10 Juegos de Roblox para una Diversión sin Límites con Amigos</h2>
        <p class="mb-6 text-lg text-gray-300">Roblox es una plataforma increíblemente social, y su verdadera magia a menudo se desata cuando juegas con amigos. Ya sea que busquen aventuras épicas, competencias intensas o simplemente pasar un buen rato, hay un juego para cada grupo. Aquí te presentamos nuestra selección de los 10 mejores juegos para disfrutar en compañía.</p>
    
        <ol class="space-y-8">
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">1. Adopt Me!</h3>
            <p class="text-gray-400">Un clásico indiscutible. En Adopt Me!, tú y tus amigos pueden criar mascotas adorables, desde perros y gatos hasta dragones y unicornios legendarios. Pueden decorar sus casas, intercambiar mascotas y explorar un mundo vibrante lleno de secretos y eventos estacionales. Es un juego relajante y perfecto para socializar.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">2. Blox Fruits</h3>
            <p class="text-gray-400">Inspirado en el famoso anime "One Piece", Blox Fruits es una aventura RPG masiva. Forma un equipo con tus amigos, naveguen por los mares, luchen contra jefes temibles y busquen las poderosas Frutas del Diablo que otorgan habilidades increíbles. La cooperación es clave para derrotar a los enemigos más fuertes y convertirse en los piratas más temidos.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">3. Murder Mystery 2</h3>
            <p class="text-gray-400">Pon a prueba tu capacidad de deducción y engaño. En cada ronda, un jugador es el asesino, otro el sheriff y los demás son inocentes. El asesino debe eliminar a todos sin ser descubierto, el sheriff debe detenerlo y los inocentes deben sobrevivir. Las risas y la tensión están garantizadas mientras intentan descubrir quién es el traidor.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">4. Tower of Hell</h3>
            <p class="text-gray-400">¿Creen que tienen buenas habilidades de parkour? Tower of Hell los pondrá a prueba. Es una carrera contra el tiempo para llegar a la cima de una torre generada proceduralmente y llena de obstáculos desafiantes. No hay checkpoints. Compitan para ver quién llega primero o ayúdense mutuamente a superar las secciones más difíciles. Es caótico, frustrante y extremadamente divertido.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">5. Brookhaven RP</h3>
            <p class="text-gray-400">Para los amantes del roleplay, Brookhaven es el paraíso. Es una ciudad virtual donde puedes ser quien quieras: un oficial de policía, un bombero, un doctor o simplemente un ciudadano. Compren casas, conduzcan coches de lujo y creen sus propias historias con amigos. Las posibilidades son infinitas.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">6. Arsenal</h3>
            <p class="text-gray-400">Si buscan acción trepidante, Arsenal es su juego. Es un shooter en primera persona de ritmo rápido donde el arma cambia con cada eliminación. La jugabilidad es caótica y adictiva. Formen equipos o compitan en un todos contra todos para ver quién domina el campo de batalla.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">7. Piggy</h3>
            <p class="text-gray-400">Un juego de terror y supervivencia que combina puzzles con persecuciones intensas. Tú y tus amigos deben resolver acertijos para escapar de diferentes mapas mientras son perseguidos por el aterrador Piggy. La comunicación es esencial para encontrar llaves, desbloquear puertas y sobrevivir juntos.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">8. Work at a Pizza Place</h3>
            <p class="text-gray-400">Un simulador de trabajo cooperativo muy entretenido. Asuman diferentes roles en una pizzería: cocinero, cajero, repartidor. Coordinen sus esfuerzos para satisfacer a los clientes y ganar dinero para mejorar sus casas. Es un juego sorprendentemente profundo y divertido en equipo.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">9. Epic Minigames</h3>
            <p class="text-gray-400">¿No pueden decidir a qué jugar? Epic Minigames les lanza a una serie de minijuegos rápidos y variados, uno tras otro. Desde carreras de plataformas hasta batallas de supervivencia, nunca sabrán qué esperar. Compitan por puntos y vean quién es el campeón definitivo de los minijuegos.</p>
          </li>
          <li>
            <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-2">10. Doors</h3>
            <p class="text-gray-400">Una experiencia de terror cooperativo de alta calidad. Naveguen por un hotel embrujado lleno de entidades aterradoras. Cada puerta presenta un nuevo desafío y cada entidad requiere una estrategia diferente para sobrevivir. La atmósfera es increíble y jugarlo con amigos hace que los sustos sean aún más memorables. ¡Asegúrense de usar auriculares!</p>
          </li>
        </ol>
        <p class="mt-8 text-lg text-gray-300">Así que reúne a tu equipo, elige un juego de esta lista y prepárate para horas de diversión. ¡Roblox es mejor cuando se comparte!</p>
      `
      };
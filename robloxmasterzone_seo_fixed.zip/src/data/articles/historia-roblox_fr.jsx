export const article = {
  slug: 'historia-secreta-de-roblox',
  title: 'L\'Histoire Secrète de Roblox : Du Simulateur de Physique au Métavers',
  description: 'Voyagez dans le temps pour découvrir les origines de Roblox. Saviez-vous que ce n\'était pas toujours un jeu ? Découvrez son incroyable évolution.',
  image: 'https://storage.googleapis.com/hostinger-horizons-assets-prod/1ac6c1b6-27b8-4b8e-b4ac-c5baf54fc1e4/5dbf7f5d9b782189abbf5aea9e1a35c4.jpg',
  category: 'Nouveautés',
  categoryKey: 'Novedades',
  content: `
  <h2 class="text-3xl font-orbitron font-bold text-green-400 mb-4">De DynaBlocks au Métavers : La Fascinante Histoire de Roblox</h2>
  <p class="mb-6 text-lg text-gray-300">Aujourd'hui, Roblox est un géant du divertissement numérique, une plateforme avec des millions de jeux et une communauté mondiale. Mais vous êtes-vous déjà demandé comment tout a commencé ? L'histoire de Roblox est un voyage incroyable qui remonte bien avant son lancement officiel en 2006. Il n'a pas commencé comme un jeu, mais comme un outil éducatif de simulation de physique.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">Les Origines : Interactive Physics (1989)</h3>
  <p class="mb-4 text-gray-400">L'histoire de Roblox commence avec ses deux fondateurs, David Baszucki et Erik Cassel. À la fin des années 1980, Baszucki a développé "Interactive Physics", un programme de simulation qui permettait aux étudiants et aux enseignants de modéliser des expériences de physique dans un environnement 2D. Ils pouvaient créer des leviers, des rampes, des collisions et voir comment les lois de la physique agissaient sur leurs créations. Ce programme a été un succès dans le domaine de l'éducation.</p>
  <p class="mb-4 text-gray-400">Baszucki a remarqué quelque chose de fascinant : les étudiants n'utilisaient pas seulement le programme pour leurs devoirs. Ils ont commencé à expérimenter, à construire des choses folles et à créer des jeux simples à l'intérieur du simulateur, comme des voitures qui s'écrasent ou des bâtiments qui s'effondrent. Il a vu le potentiel d'une plateforme où les gens pourraient créer et partager leurs propres expériences interactives en 3D. La graine de Roblox avait été plantée.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">La Naissance de "DynaBlocks" (2004)</h3>
  <p class="mb-4 text-gray-400">Après avoir vendu sa société, Baszucki s'est associé à Erik Cassel, qui avait travaillé avec lui sur Interactive Physics, pour lancer un nouveau projet. En 2004, ils ont commencé à développer une nouvelle plateforme. Le nom de code du prototype était "DynaBlocks". Ce nom reflétait la nature dynamique et basée sur des blocs de la plateforme.</p>
  <p class="mb-4 text-gray-400">Les premiers jours étaient de pure expérimentation. La première version de DynaBlocks était très primitive, avec des graphismes simples et des fonctionnalités limitées. Cependant, le cœur de l'idée était déjà là : un univers virtuel où les utilisateurs ne jouaient pas seulement, mais créaient aussi les jeux. Le moteur physique restait une partie fondamentale, permettant des créations complexes et réalistes.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">Le Changement de Nom et le Lancement (2005-2006)</h3>
  <p class="mb-4 text-gray-400">En 2005, le nom "DynaBlocks" a été changé en "Roblox", un mot-valise des mots "robots" et "blocks" (blocs). L'équipe a estimé que c'était un nom plus accrocheur et représentatif. Après des années de développement et de tests bêta, Roblox a été officiellement lancé au public en septembre 2006.</p>
  <p class="mb-4 text-gray-400">À ses débuts, Roblox était très différent de ce que nous connaissons aujourd'hui. La communauté était petite, et l'outil de création, Roblox Studio, était beaucoup plus basique. Il n'y avait pas de Robux ; la monnaie virtuelle s'appelait "Roblox Points". Malgré sa simplicité, la plateforme a commencé à attirer une communauté de créateurs passionnés qui ont vu son potentiel.</p>

  <h3 class="text-2xl font-orbitron font-bold text-purple-400 mb-3">L'Évolution vers un Métavers</h3>
  <p class="mb-4 text-gray-400">Au fil des ans, Roblox a évolué à un rythme constant :</p>
  <ul class="list-disc list-inside mb-6 space-y-2 text-gray-300">
    <li><strong>2007 :</strong> Le "Builders Club" (le précurseur de Premium) et les vêtements personnalisables sont introduits.</li>
    <li><strong>2012 :</strong> Roblox arrive sur les appareils iOS, élargissant massivement sa base de joueurs.</li>
    <li><strong>2013 :</strong> Le programme "Developer Exchange" (DevEx) est introduit, permettant aux développeurs d'échanger les Robux gagnés contre de l'argent réel. Cela a professionnalisé la création de jeux sur la plateforme.</li>
    <li><strong>2015 et au-delà :</strong> Il est lancé sur Xbox, le moteur graphique est amélioré, le support de la Réalité Virtuelle (VR) est introduit, et il s'étend à d'autres plateformes.</li>
  </ul>

  <p class="mt-6 text-lg text-gray-300">La vision de Baszucki, inspirée par ces étudiants qui jouaient avec un simulateur de physique, est devenue l'une des plus grandes plateformes de divertissement au monde. C'est un témoignage du pouvoir de la créativité et de la communauté. La prochaine fois que vous entrerez dans un jeu sur Roblox, souvenez-vous que vous participez à un héritage qui a commencé il y a plus de 30 ans avec une simple simulation de physique.</p>
`
};
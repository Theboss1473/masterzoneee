import { article as codigosRoblox } from './articles/codigos-roblox_es.js';
import { article as conseguirRobux } from './articles/conseguir-robux_es.js';
import { article as mejoresJuegos } from './articles/mejores-juegos_es.js';
import { article as eventoTheHunt } from './articles/evento-the-hunt_es.js';
import { article as accesoriosGratis } from './articles/accesorios-gratis_es.js';
import { article as generadoresEstafa } from './articles/generadores-estafa_es.js';
import { article as optimizarRendimiento } from './articles/optimizar-rendimiento_es.js';
import { article as robloxPremium } from './articles/roblox-premium_es.js';
import { article as historiaRoblox } from './articles/historia-roblox_es.js';
import { article as trucosConstruccion } from './articles/trucos-construccion_es.js';
import { article as protegerCuenta } from './articles/proteger-cuenta_es.js';

export const articles = [
  codigosRoblox,
  conseguirRobux,
  mejoresJuegos,
  eventoTheHunt,
  accesoriosGratis,
  generadoresEstafa,
  optimizarRendimiento,
  robloxPremium,
  historiaRoblox,
  trucosConstruccion,
  protegerCuenta,
];
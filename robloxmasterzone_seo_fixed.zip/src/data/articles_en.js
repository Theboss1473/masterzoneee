import { article as codigosRoblox } from './articles/codigos-roblox_en.js';
import { article as conseguirRobux } from './articles/conseguir-robux_en.js';
import { article as mejoresJuegos } from './articles/mejores-juegos_en.js';
import { article as eventoTheHunt } from './articles/evento-the-hunt_en.js';
import { article as accesoriosGratis } from './articles/accesorios-gratis_en.js';
import { article as generadoresEstafa } from './articles/generadores-estafa_en.js';
import { article as optimizarRendimiento } from './articles/optimizar-rendimiento_en.js';
import { article as robloxPremium } from './articles/roblox-premium_en.js';
import { article as historiaRoblox } from './articles/historia-roblox_en.js';
import { article as trucosConstruccion } from './articles/trucos-construccion_en.js';
import { article as protegerCuenta } from './articles/proteger-cuenta_en.js';

export const articles = [
  codigosRoblox,
  conseguirRobux,
  mejoresJuegos,
  eventoTheHunt,
  accesoriosGratis,
  generadoresEstafa,
  optimizarRendimiento,
  robloxPremium,
  historiaRoblox,
  trucosConstruccion,
  protegerCuenta,
];